sap.ui.define(
    ["sap/ovp/app/Component"],
    function (Component) {
        "use strict";

        return Component.extend("over.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);